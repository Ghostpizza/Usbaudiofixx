package com.usbaudiofix;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_NOTIF = 1;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final SimpleDateFormat timeFmt = new SimpleDateFormat("dd/MM HH:mm:ss", Locale.getDefault());

    private View pageStatus, pageDiag, pageHistory;
    private TextView tabStatus, tabDiag, tabHistory;
    private View rowUsb, rowAudio, rowPower;
    private Button btnRecover, btnDiag, btnCopy, btnClear;
    private TextView recoverResult, diagHint, historyCount, historyEmpty, monitorState;
    private Switch swMonitor, swAuto;
    private LinearLayout diagContainer;
    private ListView historyList;
    private HistoryAdapter adapter;
    private String lastReport = "";

    private final Runnable onHistoryChanged = new Runnable() {
        @Override public void run() { refreshHistory(); refreshStatus(); }
    };
    private final Runnable poll = new Runnable() {
        @Override public void run() {
            refreshStatus();
            handler.postDelayed(this, 3000);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pageStatus = findViewById(R.id.pageStatus);
        pageDiag = findViewById(R.id.pageDiag);
        pageHistory = findViewById(R.id.pageHistory);
        tabStatus = (TextView) findViewById(R.id.tabStatus);
        tabDiag = (TextView) findViewById(R.id.tabDiag);
        tabHistory = (TextView) findViewById(R.id.tabHistory);
        rowUsb = findViewById(R.id.rowUsb);
        rowAudio = findViewById(R.id.rowAudio);
        rowPower = findViewById(R.id.rowPower);
        btnRecover = (Button) findViewById(R.id.btnRecover);
        btnDiag = (Button) findViewById(R.id.btnDiag);
        btnCopy = (Button) findViewById(R.id.btnCopy);
        btnClear = (Button) findViewById(R.id.btnClear);
        recoverResult = (TextView) findViewById(R.id.recoverResult);
        diagHint = (TextView) findViewById(R.id.diagHint);
        historyCount = (TextView) findViewById(R.id.historyCount);
        historyEmpty = (TextView) findViewById(R.id.historyEmpty);
        monitorState = (TextView) findViewById(R.id.monitorState);
        swMonitor = (Switch) findViewById(R.id.swMonitor);
        swAuto = (Switch) findViewById(R.id.swAuto);
        diagContainer = (LinearLayout) findViewById(R.id.diagContainer);
        historyList = (ListView) findViewById(R.id.historyList);

        adapter = new HistoryAdapter();
        historyList.setAdapter(adapter);

        tabStatus.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { selectTab(0); }
        });
        tabDiag.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { selectTab(1); }
        });
        tabHistory.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { selectTab(2); }
        });

        btnRecover.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { doRecover(); }
        });
        btnDiag.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { doDiagnose(); }
        });
        btnCopy.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("USB Audio Fix", lastReport));
                Toast.makeText(MainActivity.this, "Relatório copiado", Toast.LENGTH_SHORT).show();
            }
        });
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                new AlertDialog.Builder(MainActivity.this, android.R.style.Theme_Material_Dialog_Alert)
                        .setMessage("Apagar todo o histórico?")
                        .setPositiveButton("Apagar", new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface d, int w) {
                                HistoryStore.clear(MainActivity.this);
                            }
                        })
                        .setNegativeButton("Cancelar", null)
                        .show();
            }
        });
        findViewById(R.id.btnMiui).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showMiuiHelp(); }
        });

        swMonitor.setChecked(Prefs.monitoring(this));
        swAuto.setChecked(Prefs.autoRecover(this));
        swMonitor.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                Prefs.setMonitoring(MainActivity.this, on);
                if (on) {
                    MonitorService.start(MainActivity.this);
                } else {
                    MonitorService.stop(MainActivity.this);
                    HistoryStore.add(MainActivity.this, HistoryStore.INFO, "Monitoramento desativado", "");
                }
                refreshStatus();
            }
        });
        swAuto.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                Prefs.setAutoRecover(MainActivity.this, on);
            }
        });

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
        }

        if (Prefs.monitoring(this) && !MonitorService.running) {
            MonitorService.start(this);
        }
        selectTab(0);
    }

    @Override protected void onResume() {
        super.onResume();
        HistoryStore.addListener(onHistoryChanged);
        refreshHistory();
        handler.post(poll);
    }

    @Override protected void onPause() {
        super.onPause();
        HistoryStore.removeListener(onHistoryChanged);
        handler.removeCallbacks(poll);
    }

    // ------------------------------------------------------------------ abas

    private void selectTab(int index) {
        pageStatus.setVisibility(index == 0 ? View.VISIBLE : View.GONE);
        pageDiag.setVisibility(index == 1 ? View.VISIBLE : View.GONE);
        pageHistory.setVisibility(index == 2 ? View.VISIBLE : View.GONE);
        styleTab(tabStatus, index == 0);
        styleTab(tabDiag, index == 1);
        styleTab(tabHistory, index == 2);
    }

    private void styleTab(TextView t, boolean selected) {
        t.setTextColor(selected ? Ui.C_BLUE : Ui.C_DIM);
        t.setTypeface(null, selected ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
    }

    // ---------------------------------------------------------------- status

    private void setRow(View row, String label, String value, int severity) {
        ((TextView) row.findViewById(R.id.label)).setText(label);
        ((TextView) row.findViewById(R.id.value)).setText(value);
        row.findViewById(R.id.dot).setBackground(Ui.dot(Ui.color(severity)));
    }

    private void refreshStatus() {
        Diagnostics.Snapshot s = Diagnostics.snapshot(this);
        setRow(rowUsb, "USB (dispositivos conectados)", s.usb, s.usbSev);
        setRow(rowAudio, "Áudio externo", s.audio, s.audioSev);
        setRow(rowPower, "Alimentação", s.power, s.powerSev);
        monitorState.setText(MonitorService.running
                ? "● Monitoramento ativo"
                : "○ Monitoramento inativo");
        monitorState.setTextColor(MonitorService.running ? Ui.C_OK : Ui.C_DIM);
    }

    private void doRecover() {
        btnRecover.setEnabled(false);
        btnRecover.setText(R.string.recovering);
        recoverResult.setVisibility(View.GONE);
        AudioRecovery.runAsync(this, new AudioRecovery.Callback() {
            @Override public void onDone(boolean ok, String report) {
                btnRecover.setEnabled(true);
                btnRecover.setText(R.string.recover);
                recoverResult.setText(report);
                recoverResult.setTextColor(ok ? Ui.C_OK : Ui.C_WARN);
                recoverResult.setVisibility(View.VISIBLE);
                refreshStatus();
            }
        });
    }

    // ------------------------------------------------------------ diagnóstico

    private void doDiagnose() {
        List<Diagnostics.Finding> findings = Diagnostics.run(this);
        lastReport = Diagnostics.toReport(findings);
        diagContainer.removeAllViews();
        diagHint.setVisibility(View.GONE);
        LayoutInflater inf = LayoutInflater.from(this);
        for (Diagnostics.Finding f : findings) {
            View v = inf.inflate(R.layout.item_event, diagContainer, false);
            bindEvent(v, f.severity, f.title, f.detail, null);
            diagContainer.addView(v);
        }
        btnCopy.setVisibility(View.VISIBLE);
    }

    // --------------------------------------------------------------- histórico

    private void refreshHistory() {
        List<HistoryStore.Event> list = HistoryStore.load(this);
        adapter.setItems(list);
        historyCount.setText(list.size() + " evento(s)");
        historyEmpty.setVisibility(list.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void bindEvent(View v, int severity, String title, String detail, String time) {
        v.findViewById(R.id.dot).setBackground(Ui.dot(Ui.color(severity)));
        ((TextView) v.findViewById(R.id.title)).setText(title);
        TextView t = (TextView) v.findViewById(R.id.time);
        if (time == null) {
            t.setVisibility(View.GONE);
        } else {
            t.setVisibility(View.VISIBLE);
            t.setText(time);
        }
        TextView d = (TextView) v.findViewById(R.id.detail);
        d.setText(detail);
        d.setVisibility(detail == null || detail.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private final class HistoryAdapter extends BaseAdapter {
        private List<HistoryStore.Event> items = new ArrayList<>();

        void setItems(List<HistoryStore.Event> l) {
            items = l;
            notifyDataSetChanged();
        }

        @Override public int getCount() { return items.size(); }
        @Override public Object getItem(int i) { return items.get(i); }
        @Override public long getItemId(int i) { return i; }

        @Override public View getView(int position, View convertView, ViewGroup parent) {
            View v = convertView != null ? convertView
                    : LayoutInflater.from(MainActivity.this).inflate(R.layout.item_event, parent, false);
            HistoryStore.Event e = items.get(position);
            bindEvent(v, e.severity, e.title, e.detail, timeFmt.format(e.time));
            return v;
        }
    }

    // -------------------------------------------------------------------- MIUI

    private void showMiuiHelp() {
        String msg = "Para o monitoramento continuar em segundo plano no MIUI 14:\n\n"
                + "• Início automático: ative o USB Audio Fix (app Segurança › Permissões).\n"
                + "• Economia de bateria do app: escolha \"Sem restrições\".\n"
                + "• Na tela de recentes, mantenha o app fixado (cadeado).\n"
                + "• Permita notificações para o app.\n\n"
                + "Esses ajustes são feitos por você nas configurações do sistema; o app não altera nada sozinho.";
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Ajustes recomendados")
                .setMessage(msg)
                .setPositiveButton("Ajustes do app", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        open(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.parse("package:" + getPackageName())));
                    }
                })
                .setNeutralButton("Bateria", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        open(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                    }
                })
                .setNegativeButton("Fechar", null)
                .show();
    }

    private void open(Intent i) {
        try {
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Tela não disponível neste aparelho", Toast.LENGTH_SHORT).show();
        }
    }
}
