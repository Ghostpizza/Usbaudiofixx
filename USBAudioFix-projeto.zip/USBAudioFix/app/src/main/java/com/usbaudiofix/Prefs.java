package com.usbaudiofix;

import android.content.Context;
import android.content.SharedPreferences;

/** Preferências simples do app. */
final class Prefs {
    private Prefs() {}

    private static SharedPreferences p(Context c) {
        return c.getApplicationContext().getSharedPreferences("settings", Context.MODE_PRIVATE);
    }

    static boolean monitoring(Context c) { return p(c).getBoolean("monitoring", true); }
    static void setMonitoring(Context c, boolean v) { p(c).edit().putBoolean("monitoring", v).apply(); }

    static boolean autoRecover(Context c) { return p(c).getBoolean("auto_recover", false); }
    static void setAutoRecover(Context c, boolean v) { p(c).edit().putBoolean("auto_recover", v).apply(); }
}
