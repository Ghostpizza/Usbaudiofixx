package com.usbaudiofix;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

/** Serviço em primeiro plano que mantém o ConnectionMonitor ativo. Sem root. */
public class MonitorService extends Service {
    private static final String CHANNEL = "monitor";
    private static final int NOTIF_ID = 1;

    static volatile boolean running = false;
    private ConnectionMonitor monitor;

    static void start(Context c) {
        try {
            Intent i = new Intent(c, MonitorService.class);
            c.startForegroundService(i);
        } catch (Exception e) {
            HistoryStore.add(c, HistoryStore.WARN, "Não foi possível iniciar o monitoramento",
                    String.valueOf(e.getMessage()));
        }
    }

    static void stop(Context c) {
        c.stopService(new Intent(c, MonitorService.class));
    }

    @Override public void onCreate() {
        super.onCreate();
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Monitoramento",
                NotificationManager.IMPORTANCE_LOW));

        PendingIntent pi = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("USB Audio Fix")
                .setContentText("Monitorando conexões USB e áudio")
                .setContentIntent(pi)
                .setOngoing(true)
                .build();

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIF_ID, n);
        }

        monitor = new ConnectionMonitor(this);
        monitor.start();
        running = true;
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override public void onDestroy() {
        running = false;
        if (monitor != null) monitor.stop();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
