package com.usbaudiofix;

import android.graphics.drawable.GradientDrawable;

/** Utilidades visuais (cores por severidade e bolinhas de status). */
final class Ui {
    private Ui() {}

    static final int C_OK = 0xFF3DDC97;
    static final int C_WARN = 0xFFFFB020;
    static final int C_ERR = 0xFFFF5C6C;
    static final int C_INFO = 0xFF6AA8FF;
    static final int C_BLUE = 0xFF2F80FF;
    static final int C_DIM = 0xFF8A97AD;

    static int color(int severity) {
        if (severity == HistoryStore.OK) return C_OK;
        if (severity == HistoryStore.WARN) return C_WARN;
        if (severity == HistoryStore.ERROR) return C_ERR;
        return C_INFO;
    }

    static GradientDrawable dot(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        return g;
    }
}
