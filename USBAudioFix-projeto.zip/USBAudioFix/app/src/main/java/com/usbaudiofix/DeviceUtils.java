package com.usbaudiofix;

import android.media.AudioDeviceInfo;
import android.media.AudioManager;

import java.util.ArrayList;
import java.util.List;

/** Funções auxiliares sobre dispositivos de áudio (somente APIs públicas). */
final class DeviceUtils {
    private DeviceUtils() {}

    static boolean isExternalOutputType(int t) {
        switch (t) {
            case AudioDeviceInfo.TYPE_WIRED_HEADSET:
            case AudioDeviceInfo.TYPE_WIRED_HEADPHONES:
            case AudioDeviceInfo.TYPE_USB_HEADSET:
            case AudioDeviceInfo.TYPE_USB_DEVICE:
            case AudioDeviceInfo.TYPE_USB_ACCESSORY:
            case AudioDeviceInfo.TYPE_LINE_ANALOG:
            case AudioDeviceInfo.TYPE_LINE_DIGITAL:
            case AudioDeviceInfo.TYPE_AUX_LINE:
                return true;
            default:
                return false;
        }
    }

    static boolean isUsbType(int t) {
        return t == AudioDeviceInfo.TYPE_USB_HEADSET
                || t == AudioDeviceInfo.TYPE_USB_DEVICE
                || t == AudioDeviceInfo.TYPE_USB_ACCESSORY;
    }

    static String typeName(int t) {
        switch (t) {
            case AudioDeviceInfo.TYPE_WIRED_HEADSET: return "Fone com microfone (P2)";
            case AudioDeviceInfo.TYPE_WIRED_HEADPHONES: return "Fone de ouvido (P2)";
            case AudioDeviceInfo.TYPE_USB_HEADSET: return "Headset USB";
            case AudioDeviceInfo.TYPE_USB_DEVICE: return "Dispositivo de áudio USB";
            case AudioDeviceInfo.TYPE_USB_ACCESSORY: return "Acessório de áudio USB";
            case AudioDeviceInfo.TYPE_LINE_ANALOG: return "Saída analógica (line)";
            case AudioDeviceInfo.TYPE_LINE_DIGITAL: return "Saída digital (line)";
            case AudioDeviceInfo.TYPE_AUX_LINE: return "Saída AUX";
            case AudioDeviceInfo.TYPE_BUILTIN_SPEAKER: return "Alto-falante interno";
            case AudioDeviceInfo.TYPE_BUILTIN_EARPIECE: return "Auricular interno";
            case AudioDeviceInfo.TYPE_BLUETOOTH_A2DP: return "Bluetooth A2DP";
            case AudioDeviceInfo.TYPE_BLUETOOTH_SCO: return "Bluetooth SCO";
            default: return "Tipo " + t;
        }
    }

    static String describe(AudioDeviceInfo d) {
        CharSequence n = d.getProductName();
        String name = n == null ? "" : n.toString().trim();
        return typeName(d.getType()) + (name.isEmpty() ? "" : " — " + name);
    }

    static List<AudioDeviceInfo> externalOutputs(AudioManager am) {
        List<AudioDeviceInfo> out = new ArrayList<>();
        if (am == null) return out;
        for (AudioDeviceInfo d : am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
            if (isExternalOutputType(d.getType())) out.add(d);
        }
        return out;
    }

    static String names(List<AudioDeviceInfo> list) {
        if (list.isEmpty()) return "nenhuma saída externa";
        StringBuilder sb = new StringBuilder();
        for (AudioDeviceInfo d : list) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(describe(d));
        }
        return sb.toString();
    }
}
