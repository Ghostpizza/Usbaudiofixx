package com.usbaudiofix;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioFormat;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Handler;
import android.os.Looper;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Tenta "acordar" a rota de áudio usando apenas APIs públicas:
 * normaliza o modo de áudio, pede foco de áudio e abre uma saída de mídia
 * com sinal silencioso (direcionada ao dispositivo externo, se existir).
 * Não controla o hardware USB-C e não usa root.
 */
final class AudioRecovery {
    private AudioRecovery() {}

    interface Callback {
        void onDone(boolean ok, String report);
    }

    private static final AtomicBoolean RUNNING = new AtomicBoolean(false);

    /** O callback (opcional) é chamado na thread principal. O resultado também vai ao histórico. */
    static void runAsync(Context ctx, final Callback cb) {
        final Context app = ctx.getApplicationContext();
        final Handler main = new Handler(Looper.getMainLooper());
        if (!RUNNING.compareAndSet(false, true)) {
            if (cb != null) main.post(new Runnable() {
                @Override public void run() { cb.onDone(false, "Já existe uma recuperação em andamento."); }
            });
            return;
        }
        new Thread(new Runnable() {
            @Override public void run() {
                boolean ok = false;
                String report;
                try {
                    StringBuilder sb = new StringBuilder();
                    ok = execute(app, sb);
                    report = sb.toString();
                } catch (Exception e) {
                    report = "Falha inesperada: " + e.getMessage();
                } finally {
                    RUNNING.set(false);
                }
                final boolean fOk = ok;
                final String fReport = report;
                HistoryStore.add(app, fOk ? HistoryStore.OK : HistoryStore.WARN,
                        "Tentativa de recuperar o áudio", fReport);
                if (cb != null) main.post(new Runnable() {
                    @Override public void run() { cb.onDone(fOk, fReport); }
                });
            }
        }, "usb-audio-recovery").start();
    }

    private static AudioAttributes mediaAttrs() {
        return new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();
    }

    private static boolean execute(Context app, StringBuilder sb) throws InterruptedException {
        AudioManager am = (AudioManager) app.getSystemService(Context.AUDIO_SERVICE);
        List<AudioDeviceInfo> before = DeviceUtils.externalOutputs(am);
        sb.append("1) Estado inicial: ").append(DeviceUtils.names(before)).append('\n');

        // 2) Modo de áudio normal
        try {
            if (am.getMode() != AudioManager.MODE_NORMAL) {
                am.setMode(AudioManager.MODE_NORMAL);
                sb.append("2) Modo de áudio restaurado para normal.\n");
            } else {
                sb.append("2) Modo de áudio já estava normal.\n");
            }
        } catch (SecurityException e) {
            sb.append("2) Sem permissão para alterar o modo de áudio.\n");
        }

        // 3) Foco de áudio
        AudioFocusRequest focus = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setAudioAttributes(mediaAttrs())
                .setOnAudioFocusChangeListener(new AudioManager.OnAudioFocusChangeListener() {
                    @Override public void onAudioFocusChange(int change) { }
                })
                .build();
        int r = am.requestAudioFocus(focus);
        sb.append("3) Foco de áudio: ")
                .append(r == AudioManager.AUDIOFOCUS_REQUEST_GRANTED ? "obtido" : "não concedido")
                .append('\n');

        // 4) Sinal silencioso para reabrir a rota
        sb.append("4) ").append(playSilence(before)).append('\n');

        // 5) Reavalia por até ~3 s
        List<AudioDeviceInfo> after = DeviceUtils.externalOutputs(am);
        for (int i = 0; i < 6 && after.isEmpty(); i++) {
            Thread.sleep(500);
            after = DeviceUtils.externalOutputs(am);
        }
        am.abandonAudioFocusRequest(focus);

        sb.append("5) Estado final: ").append(DeviceUtils.names(after)).append("\n\n");
        if (!after.isEmpty()) {
            sb.append("✔ Saída de áudio externa ativa.");
            return true;
        }
        sb.append("✘ O Android ainda não enxerga uma saída externa.\n")
          .append("Isso normalmente é limitação física do adaptador: o app não pode religar a porta USB-C.\n")
          .append("Tente, nesta ordem:\n")
          .append("• Desconecte o carregador e aguarde 3 s.\n")
          .append("• Reconecte o adaptador ao celular e o fone ao P2.\n")
          .append("• Só depois conecte o carregador.\n")
          .append("• Se cair de novo, o adaptador provavelmente não suporta áudio + carga simultâneos.");
        return false;
    }

    private static String playSilence(List<AudioDeviceInfo> ext) {
        AudioTrack track = null;
        try {
            int rate = 48000;
            int min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_STEREO,
                    AudioFormat.ENCODING_PCM_16BIT);
            if (min <= 0) min = 8192;
            track = new AudioTrack.Builder()
                    .setAudioAttributes(mediaAttrs())
                    .setAudioFormat(new AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(rate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                            .build())
                    .setBufferSizeInBytes(min * 2)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build();
            boolean preferred = false;
            if (!ext.isEmpty()) preferred = track.setPreferredDevice(ext.get(0));
            track.play();
            byte[] zeros = new byte[min];
            int total = rate * 4; // ~1 s de áudio estéreo 16-bit
            int written = 0;
            while (written < total) {
                int n = track.write(zeros, 0, zeros.length);
                if (n < 0) break;
                written += n;
            }
            track.stop();
            return "Sinal silencioso enviado para reabrir a rota de áudio"
                    + (preferred ? " (direcionado ao dispositivo externo)." : ".");
        } catch (Exception e) {
            return "Não foi possível abrir uma saída de áudio: " + e.getMessage();
        } finally {
            if (track != null) {
                try { track.release(); } catch (Exception ignored) { }
            }
        }
    }
}
