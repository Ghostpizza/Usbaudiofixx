package com.usbaudiofix;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.media.AudioDeviceCallback;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import java.util.Locale;

/**
 * Observa eventos públicos do Android (USB, áudio, fone P2 e energia),
 * grava no histórico e correlaciona "carregador conectado" com "áudio caiu".
 */
final class ConnectionMonitor {
    private static final String ACTION_USB_STATE = "android.hardware.usb.action.USB_STATE";
    private static final long WINDOW_MS = 8000;

    private final Context ctx;
    private final AudioManager am;
    private final Handler h = new Handler(Looper.getMainLooper());

    private boolean started;
    private volatile boolean ignoreInitial;
    private long lastPowerMs, lastDropMs, lastCorrelatedDrop;
    private String lastUsbSig = "";

    ConnectionMonitor(Context c) {
        ctx = c.getApplicationContext();
        am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
    }

    void start() {
        if (started) return;
        started = true;
        ignoreInitial = true;

        am.registerAudioDeviceCallback(deviceCallback, h);

        IntentFilter f = new IntentFilter();
        f.addAction(ACTION_USB_STATE);
        f.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED);
        f.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
        f.addAction(Intent.ACTION_POWER_CONNECTED);
        f.addAction(Intent.ACTION_POWER_DISCONNECTED);
        f.addAction(AudioManager.ACTION_AUDIO_BECOMING_NOISY);
        f.addAction(AudioManager.ACTION_HEADSET_PLUG);
        if (Build.VERSION.SDK_INT >= 33) {
            ctx.registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED);
        } else {
            ctx.registerReceiver(receiver, f);
        }

        h.postDelayed(new Runnable() {
            @Override public void run() { ignoreInitial = false; }
        }, 1500);

        HistoryStore.add(ctx, HistoryStore.INFO, "Monitoramento iniciado",
                "Saídas externas: " + DeviceUtils.names(DeviceUtils.externalOutputs(am)));
    }

    void stop() {
        if (!started) return;
        started = false;
        try { am.unregisterAudioDeviceCallback(deviceCallback); } catch (Exception ignored) { }
        try { ctx.unregisterReceiver(receiver); } catch (Exception ignored) { }
        h.removeCallbacksAndMessages(null);
    }

    // ------------------------------------------------------------------ áudio

    private final AudioDeviceCallback deviceCallback = new AudioDeviceCallback() {
        @Override public void onAudioDevicesAdded(AudioDeviceInfo[] added) {
            if (ignoreInitial) return;
            long now = System.currentTimeMillis();
            for (AudioDeviceInfo d : added) {
                if (!d.isSink() || !DeviceUtils.isExternalOutputType(d.getType())) continue;
                String extra = "";
                if (lastDropMs > 0 && now - lastDropMs < 60000) {
                    extra = String.format(Locale.getDefault(), "\nVoltou %.1f s após a queda.",
                            (now - lastDropMs) / 1000.0);
                }
                HistoryStore.add(ctx, HistoryStore.OK, "Áudio externo conectado",
                        DeviceUtils.describe(d) + extra);
            }
        }

        @Override public void onAudioDevicesRemoved(AudioDeviceInfo[] removed) {
            if (ignoreInitial) return;
            for (AudioDeviceInfo d : removed) {
                if (!d.isSink() || !DeviceUtils.isExternalOutputType(d.getType())) continue;
                lastDropMs = System.currentTimeMillis();
                HistoryStore.add(ctx, HistoryStore.ERROR, HistoryStore.T_DROP, DeviceUtils.describe(d));
                checkCorrelation();
            }
        }
    };

    // -------------------------------------------------------------- broadcasts

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            String a = i.getAction();
            if (a == null) return;
            if (ACTION_USB_STATE.equals(a)) {
                onUsbState(i);
            } else if (UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(a)) {
                logUsbDevice(i, true);
            } else if (UsbManager.ACTION_USB_DEVICE_DETACHED.equals(a)) {
                logUsbDevice(i, false);
            } else if (Intent.ACTION_POWER_CONNECTED.equals(a)) {
                lastPowerMs = System.currentTimeMillis();
                HistoryStore.add(ctx, HistoryStore.INFO, "Carregador conectado", powerDetail());
                checkCorrelation();
            } else if (Intent.ACTION_POWER_DISCONNECTED.equals(a)) {
                HistoryStore.add(ctx, HistoryStore.INFO, "Carregador desconectado", powerDetail());
            } else if (AudioManager.ACTION_AUDIO_BECOMING_NOISY.equals(a)) {
                HistoryStore.add(ctx, HistoryStore.WARN, "Saída de áudio externa removida",
                        "O Android sinalizou que a saída externa foi retirada (becoming noisy).");
            } else if (AudioManager.ACTION_HEADSET_PLUG.equals(a)) {
                int state = i.getIntExtra("state", -1);
                int mic = i.getIntExtra("microphone", 0);
                String name = i.getStringExtra("name");
                HistoryStore.add(ctx, state == 1 ? HistoryStore.OK : HistoryStore.WARN,
                        state == 1 ? "Fone P2 conectado" : "Fone P2 removido",
                        (name == null ? "" : name + " · ") + (mic == 1 ? "com microfone" : "sem microfone"));
            }
        }
    };

    private void onUsbState(Intent i) {
        Bundle e = i.getExtras();
        if (e == null) return;
        boolean connected = e.getBoolean("connected", false);
        boolean configured = e.getBoolean("configured", false);
        boolean host = e.getBoolean("host_connected", false);
        StringBuilder fn = new StringBuilder();
        for (String k : e.keySet()) {
            if (k.equals("connected") || k.equals("configured") || k.equals("host_connected")
                    || k.equals("unlocked")) continue;
            if (e.getBoolean(k, false)) {
                if (fn.length() > 0) fn.append(", ");
                fn.append(k);
            }
        }
        String sig = connected + "|" + configured + "|" + host + "|" + fn;
        if (sig.equals(lastUsbSig)) return;
        lastUsbSig = sig;
        if (ignoreInitial) return; // primeira leitura (sticky) não é evento novo
        HistoryStore.add(ctx, HistoryStore.INFO,
                connected ? "Barramento USB ativo" : "Barramento USB inativo",
                "Configurado: " + (configured ? "sim" : "não")
                        + " · Funções: " + (fn.length() == 0 ? "nenhuma" : fn));
    }

    private void logUsbDevice(Intent i, boolean attached) {
        UsbDevice d;
        if (Build.VERSION.SDK_INT >= 33) {
            d = i.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice.class);
        } else {
            d = legacyDevice(i);
        }
        String desc = "Dispositivo desconhecido";
        if (d != null) {
            String n = d.getProductName();
            desc = (n == null ? d.getDeviceName() : n) + (hasAudioInterface(d) ? " (classe de áudio)" : "");
        }
        HistoryStore.add(ctx, attached ? HistoryStore.OK : HistoryStore.WARN,
                attached ? "Dispositivo USB conectado" : "Dispositivo USB desconectado", desc);
    }

    @SuppressWarnings("deprecation")
    private static UsbDevice legacyDevice(Intent i) {
        return i.getParcelableExtra(UsbManager.EXTRA_DEVICE);
    }

    static boolean hasAudioInterface(UsbDevice d) {
        for (int k = 0; k < d.getInterfaceCount(); k++) {
            if (d.getInterface(k).getInterfaceClass() == UsbConstants.USB_CLASS_AUDIO) return true;
        }
        return false;
    }

    private String powerDetail() {
        Intent b = ctx.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (b == null) return "";
        int plugged = b.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
        return "Fonte: " + Diagnostics.plugName(plugged) + " · Bateria " + Diagnostics.batteryPercent(b) + "%";
    }

    // ------------------------------------------------------------ correlação

    private void checkCorrelation() {
        if (lastPowerMs == 0 || lastDropMs == 0 || lastDropMs == lastCorrelatedDrop) return;
        long diff = Math.abs(lastPowerMs - lastDropMs);
        if (diff > WINDOW_MS) return;
        lastCorrelatedDrop = lastDropMs;
        HistoryStore.add(ctx, HistoryStore.WARN, HistoryStore.T_CORR,
                String.format(Locale.getDefault(),
                        "Diferença de %.1f s entre o carregador e a queda do áudio. "
                                + "Isso sugere que o adaptador não mantém áudio e carga ao mesmo tempo.",
                        diff / 1000.0));
        if (Prefs.autoRecover(ctx)) {
            h.postDelayed(new Runnable() {
                @Override public void run() { AudioRecovery.runAsync(ctx, null); }
            }, 2500);
        }
    }
}
