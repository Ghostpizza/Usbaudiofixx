package com.usbaudiofix;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.PowerManager;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

/** Leitura do estado atual e análise de problemas (somente APIs públicas). */
final class Diagnostics {
    private Diagnostics() {}

    static final class Finding {
        final int severity;
        final String title;
        final String detail;
        Finding(int severity, String title, String detail) {
            this.severity = severity;
            this.title = title;
            this.detail = detail;
        }
    }

    static final class Snapshot {
        String usb, audio, power;
        int usbSev, audioSev, powerSev;
    }

    // ---------------------------------------------------------------- helpers

    static Intent battery(Context c) {
        return c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
    }

    static int batteryPercent(Intent b) {
        int level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        return level < 0 ? -1 : Math.round(level * 100f / scale);
    }

    static String plugName(int plugged) {
        if (plugged == 0) return "bateria";
        StringBuilder sb = new StringBuilder();
        if ((plugged & BatteryManager.BATTERY_PLUGGED_AC) != 0) sb.append("tomada/AC");
        if ((plugged & BatteryManager.BATTERY_PLUGGED_USB) != 0) {
            if (sb.length() > 0) sb.append(" + ");
            sb.append("USB");
        }
        if ((plugged & BatteryManager.BATTERY_PLUGGED_WIRELESS) != 0) {
            if (sb.length() > 0) sb.append(" + ");
            sb.append("sem fio");
        }
        return sb.length() == 0 ? "outra fonte" : sb.toString();
    }

    private static String usbLabel(UsbDevice d) {
        String n = d.getProductName();
        if (n == null || n.trim().isEmpty()) n = d.getDeviceName();
        return n + (ConnectionMonitor.hasAudioInterface(d) ? " [áudio USB]" : "");
    }

    private static HashMap<String, UsbDevice> usbDevices(Context c) {
        UsbManager um = (UsbManager) c.getSystemService(Context.USB_SERVICE);
        return um == null ? null : um.getDeviceList();
    }

    private static boolean isXiaomiFamily() {
        String m = Build.MANUFACTURER == null ? "" : Build.MANUFACTURER.toLowerCase(Locale.ROOT);
        String b = Build.BRAND == null ? "" : Build.BRAND.toLowerCase(Locale.ROOT);
        return m.contains("xiaomi") || b.contains("xiaomi") || b.contains("redmi") || b.contains("poco");
    }

    // --------------------------------------------------------------- snapshot

    static Snapshot snapshot(Context c) {
        Snapshot s = new Snapshot();
        AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);

        // USB
        HashMap<String, UsbDevice> map = usbDevices(c);
        if (map == null || map.isEmpty()) {
            s.usb = "Nenhum dispositivo USB em modo host";
            s.usbSev = HistoryStore.INFO;
        } else {
            StringBuilder sb = new StringBuilder();
            for (UsbDevice d : map.values()) {
                if (sb.length() > 0) sb.append("\n");
                sb.append(usbLabel(d));
            }
            s.usb = sb.toString();
            s.usbSev = HistoryStore.OK;
        }

        // Energia
        Intent b = battery(c);
        int plugged = b == null ? 0 : b.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
        int pct = b == null ? -1 : batteryPercent(b);
        String pctText = pct < 0 ? "" : " (" + pct + "%)";
        if (plugged != 0) {
            s.power = "Carregando via " + plugName(plugged) + pctText;
            s.powerSev = HistoryStore.OK;
        } else {
            s.power = "Na bateria" + pctText;
            s.powerSev = HistoryStore.INFO;
        }

        // Áudio
        List<AudioDeviceInfo> ext = DeviceUtils.externalOutputs(am);
        if (ext.isEmpty()) {
            s.audio = "Sem saída externa (usando alto-falante/fone interno)";
            s.audioSev = plugged != 0 ? HistoryStore.WARN : HistoryStore.INFO;
        } else {
            s.audio = DeviceUtils.names(ext);
            s.audioSev = HistoryStore.OK;
        }
        return s;
    }

    // ------------------------------------------------------------ diagnóstico

    static List<Finding> run(Context c) {
        List<Finding> out = new ArrayList<>();
        AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
        List<AudioDeviceInfo> ext = DeviceUtils.externalOutputs(am);
        boolean usbAudio = false;
        for (AudioDeviceInfo d : ext) if (DeviceUtils.isUsbType(d.getType())) usbAudio = true;

        Intent b = battery(c);
        int plugged = b == null ? 0 : b.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
        boolean charging = plugged != 0;

        // 1) Saída de áudio
        if (!ext.isEmpty()) {
            out.add(new Finding(HistoryStore.OK, "Saída de áudio externa detectada",
                    DeviceUtils.names(ext) + (usbAudio
                            ? "\nO Android reconhece o adaptador como áudio USB."
                            : "\nO Android reconhece como saída analógica (P2).")));
        } else {
            out.add(new Finding(HistoryStore.WARN, "Nenhuma saída de áudio externa",
                    "O Android está usando o alto-falante ou fone interno."
                            + (charging ? "\nHá um carregador conectado: veja o item sobre carregador abaixo."
                            : "\nVerifique se o adaptador está bem encaixado e funciona em outro aparelho.")));
        }

        // 2) Dispositivos USB host
        HashMap<String, UsbDevice> map = usbDevices(c);
        if (map == null || map.isEmpty()) {
            out.add(new Finding(ext.isEmpty() ? HistoryStore.WARN : HistoryStore.INFO,
                    "Nenhum dispositivo USB em modo host",
                    "Adaptadores analógicos (sem chip DAC) não aparecem como dispositivo USB; "
                            + "o áudio sai pelo modo de acessório de áudio. Isso é normal para adaptadores simples."));
        } else {
            StringBuilder sb = new StringBuilder();
            boolean anyAudio = false;
            for (UsbDevice d : map.values()) {
                if (sb.length() > 0) sb.append("\n");
                sb.append(usbLabel(d));
                if (ConnectionMonitor.hasAudioInterface(d)) anyAudio = true;
            }
            out.add(new Finding(HistoryStore.OK, "Dispositivos USB conectados (" + map.size() + ")",
                    sb + (anyAudio ? "" : "\nNenhum expõe interface de áudio USB.")));
        }

        // 3) Carregador x áudio
        if (charging && ext.isEmpty()) {
            out.add(new Finding(HistoryStore.WARN, "Carregador conectado sem áudio externo",
                    "Fonte: " + plugName(plugged) + ".\n"
                            + "Adaptadores USB-C → P2 simples usam a porta para áudio analógico e, em geral, "
                            + "não permitem carga ao mesmo tempo: ao ligar o carregador a saída some. "
                            + "Isso é limite do hardware/firmware; o app não consegue contornar sem root.\n"
                            + "Adaptadores com chip DAC e passagem de energia (PD pass-through) costumam funcionar. "
                            + "Teste também a ordem: carregador primeiro, depois o fone."));
        } else if (charging) {
            out.add(new Finding(HistoryStore.OK, "Carregando com áudio externo ativo",
                    "Fonte: " + plugName(plugged) + ". Seu adaptador mantém áudio e carga juntos."));
        } else {
            out.add(new Finding(HistoryStore.INFO, "Sem carregador conectado",
                    "Para testar: conecte o carregador e acompanhe a aba Histórico."));
        }

        // 4) Estado do áudio do sistema
        int vol = am.getStreamVolume(AudioManager.STREAM_MUSIC);
        int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        if (vol == 0 || am.isStreamMute(AudioManager.STREAM_MUSIC)) {
            out.add(new Finding(HistoryStore.WARN, "Volume de mídia zerado ou mudo",
                    "Aumente o volume de mídia. Em alguns aparelhos o volume é salvo por tipo de saída."));
        } else {
            out.add(new Finding(HistoryStore.OK, "Volume de mídia",
                    vol + " de " + max));
        }

        if (am.getMode() != AudioManager.MODE_NORMAL) {
            out.add(new Finding(HistoryStore.WARN, "Modo de áudio não é o normal",
                    "Há uma chamada ou app de comunicação usando o áudio. Isso pode prender a rota. "
                            + "O botão Recuperar áudio tenta restaurar o modo normal."));
        }
        if (am.isMusicActive()) {
            out.add(new Finding(HistoryStore.INFO, "Há mídia tocando agora",
                    "Pause a reprodução antes de testar a recuperação."));
        }

        // 5) Histórico recente
        long weekAgo = System.currentTimeMillis() - 7L * 24 * 3600 * 1000;
        int drops = 0, corr = 0;
        for (HistoryStore.Event e : HistoryStore.load(c)) {
            if (e.time < weekAgo) continue;
            if (HistoryStore.T_DROP.equals(e.title)) drops++;
            if (HistoryStore.T_CORR.equals(e.title)) corr++;
        }
        if (corr > 0) {
            out.add(new Finding(HistoryStore.WARN, "Padrão detectado no histórico",
                    corr + " de " + drops + " queda(s) de áudio nos últimos 7 dias coincidiram com a "
                            + "conexão do carregador. É o comportamento típico de adaptador sem suporte a áudio + carga."));
        } else if (drops > 0) {
            out.add(new Finding(HistoryStore.INFO, "Quedas de áudio registradas",
                    drops + " queda(s) nos últimos 7 dias, sem relação clara com o carregador."));
        }

        // 6) Permissões e economia de bateria (importantes para monitoramento contínuo)
        if (Build.VERSION.SDK_INT >= 33
                && c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            out.add(new Finding(HistoryStore.WARN, "Notificações bloqueadas",
                    "Sem permissão de notificação, o MIUI pode encerrar o serviço de monitoramento mais facilmente."));
        }
        PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
        if (pm != null && !pm.isIgnoringBatteryOptimizations(c.getPackageName())) {
            out.add(new Finding(HistoryStore.INFO, "Economia de bateria ativa para o app",
                    "O sistema pode pausar o monitoramento em segundo plano. Use o botão \"Ajustes para MIUI / bateria\"."));
        }
        if (isXiaomiFamily()) {
            out.add(new Finding(HistoryStore.INFO, "Aparelho Xiaomi / MIUI",
                    "Ative o Início automático do app e defina a bateria como \"Sem restrições\" "
                            + "para o monitoramento não ser encerrado."));
        }
        return out;
    }

    static String toReport(List<Finding> findings) {
        StringBuilder sb = new StringBuilder();
        sb.append("USB Audio Fix — relatório\n");
        sb.append(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(new Date())).append('\n');
        sb.append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
                .append(" · Android ").append(Build.VERSION.RELEASE)
                .append(" (API ").append(Build.VERSION.SDK_INT).append(")\n\n");
        for (Finding f : findings) {
            String tag = f.severity == HistoryStore.OK ? "OK"
                    : f.severity == HistoryStore.WARN ? "ATENÇÃO"
                    : f.severity == HistoryStore.ERROR ? "ERRO" : "INFO";
            sb.append('[').append(tag).append("] ").append(f.title).append('\n')
                    .append(f.detail).append("\n\n");
        }
        return sb.toString().trim();
    }
}
