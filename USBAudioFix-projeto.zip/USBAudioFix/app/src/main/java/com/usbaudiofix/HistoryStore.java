package com.usbaudiofix;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/** Histórico persistente (SharedPreferences, JSON) de conexões e desconexões. */
final class HistoryStore {
    private HistoryStore() {}

    static final int INFO = 0, OK = 1, WARN = 2, ERROR = 3;
    static final String T_DROP = "Áudio externo desconectado";
    static final String T_CORR = "Queda coincide com o carregador";
    static final int MAX = 300;

    private static final String PREFS = "history_store";
    private static final String KEY = "events";
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final List<Runnable> LISTENERS = new CopyOnWriteArrayList<>();

    static final class Event {
        final long time;
        final int severity;
        final String title;
        final String detail;

        Event(long time, int severity, String title, String detail) {
            this.time = time;
            this.severity = severity;
            this.title = title;
            this.detail = detail;
        }
    }

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static synchronized void add(Context c, int severity, String title, String detail) {
        List<Event> list = load(c);
        list.add(0, new Event(System.currentTimeMillis(), severity, title, detail == null ? "" : detail));
        while (list.size() > MAX) list.remove(list.size() - 1);
        save(c, list);
        notifyChanged();
    }

    static synchronized List<Event> load(Context c) {
        List<Event> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs(c).getString(KEY, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                out.add(new Event(o.optLong("t"), o.optInt("s"), o.optString("ti"), o.optString("d")));
            }
        } catch (Exception ignored) {
            // histórico corrompido: começa vazio
        }
        return out;
    }

    static synchronized void clear(Context c) {
        prefs(c).edit().remove(KEY).apply();
        notifyChanged();
    }

    private static void save(Context c, List<Event> list) {
        JSONArray arr = new JSONArray();
        try {
            for (Event e : list) {
                JSONObject o = new JSONObject();
                o.put("t", e.time);
                o.put("s", e.severity);
                o.put("ti", e.title);
                o.put("d", e.detail);
                arr.put(o);
            }
        } catch (Exception ignored) {
        }
        prefs(c).edit().putString(KEY, arr.toString()).apply();
    }

    static void addListener(Runnable r) { if (!LISTENERS.contains(r)) LISTENERS.add(r); }
    static void removeListener(Runnable r) { LISTENERS.remove(r); }

    private static void notifyChanged() {
        for (Runnable r : LISTENERS) MAIN.post(r);
    }
}
