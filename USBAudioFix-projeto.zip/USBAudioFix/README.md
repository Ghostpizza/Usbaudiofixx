# USB Audio Fix

App Android (Java, sem root, sem dependências externas) que monitora a conexão USB-C, o áudio externo (P2/USB) e o carregador, registra um histórico e tenta recuperar o áudio usando apenas APIs públicas.

- minSdk 26 · targetSdk 34 · compatível com MIUI 14 (Android 12/13)
- Permissões: notificações, serviço em primeiro plano, MODIFY_AUDIO_SETTINGS (todas normais, sem root)

## Gerar o APK

**Opção A – Android Studio:** abra a pasta, aguarde o sync e use *Build › Build APK(s)*.
Saída: `app/build/outputs/apk/debug/app-debug.apk`

**Opção B – GitHub Actions (sem instalar nada):** suba a pasta para um repositório; o workflow
`.github/workflows/build.yml` compila e publica o `app-debug.apk` em *Actions › Artifacts*.

**Opção C – linha de comando:** com JDK 17 + Android SDK 34 + Gradle 8.5: `gradle assembleDebug`

O APK debug já é assinado com a chave de debug e pode ser instalado direto (habilite "instalar de fontes desconhecidas").

## O que o app faz / não faz
Faz: detecta queda da saída de áudio externa, correlaciona com a conexão do carregador, guarda histórico,
roda diagnóstico, tenta reabrir a rota de áudio (modo normal + foco de áudio + sinal silencioso direcionado ao dispositivo externo).

Não faz: religar a porta USB-C, forçar o modo host/acessório ou contornar adaptadores que não suportam
áudio + carga simultâneos. Isso depende do hardware e do firmware e exigiria privilégios que apps comuns não têm.
